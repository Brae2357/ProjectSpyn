function updateKey(eventKey)
    global key
    key = eventKey;
end